INSERT INTO shop (price, product_name, description, owner, id)
VALUES (1000000, 'flag', 'flag{second_flag}', 'admin', 1) ;