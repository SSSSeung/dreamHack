FLAG = 'DH{pingpingppppppppping!!}'
